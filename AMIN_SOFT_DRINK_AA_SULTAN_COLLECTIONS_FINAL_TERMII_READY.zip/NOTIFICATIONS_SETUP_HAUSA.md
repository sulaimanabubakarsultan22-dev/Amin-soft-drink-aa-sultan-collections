# Termii SMS — saitin sanarwar oda

An haɗa sanarwar SMS ta Termii a gefen server. Ba a saka API key a cikin source code ko wannan ZIP ba.

## Lambobin da za su karɓi sanarwa
- 08163827505
- 07046918331

An sa su a matsayin tsoffin lambobi a `server.js`; `ADMIN_PHONE` da `MANAGER_PHONE` a Render za su iya maye gurbinsu idan an sa su. Ana canza lambobin Najeriya zuwa tsarin ƙasa da ƙasa na Termii ta atomatik.

## Render Environment
Saita waɗannan a Render → Environment:
- `TERMII_API_KEY` = API key ɗinka na Termii (kada ka aika wa kowa).
- `TERMII_API_BASE_URL` = ainihin Base URL da dashboard ɗin Termii ya nuna.
- `TERMII_SENDER_ID` = sender ID da Termii ta amince da shi.
- `TERMII_SMS_CHANNEL` = `dnd` don sanarwar oda/biyan kuɗi; wannan route na iya buƙatar Termii ta kunna shi a account ɗinka.
- `ADMIN_PHONE` = `08163827505`
- `MANAGER_PHONE` = `07046918331`

## Abin da ake aikawa
- Lokacin da aka ƙirƙiri oda: kayayyaki, adadi, farashi, jimilla, kuɗin delivery, sunan/wayar kwastoma da adireshi idan suna nan.
- Lokacin da Paystack ya tabbatar da biyan kuɗi: sanarwar an tabbatar da biya.
- Idan an gano ƙarin biyan kuɗi da ake buƙatar mayarwa: sanarwa don a duba dashboard.

Idan Termii ta ƙi aika SMS, oda da biyan Paystack ba za su tsaya ba. SMS ba zai fara aiki ba sai an sa API key, Base URL, sender ID mai izini, kuma Termii account ya ba da damar channel ɗin da aka zaɓa.
