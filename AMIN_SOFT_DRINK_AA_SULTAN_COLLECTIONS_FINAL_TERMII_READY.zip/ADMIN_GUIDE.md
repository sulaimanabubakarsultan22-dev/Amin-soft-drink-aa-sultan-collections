# AMIN SOFT DRINK & A.A SULTAN COLLECTIONS — Admin Guide

## Add a new product
1. Open **Admin > Products > + Add product**.
2. Enter the product name, category, unit price and stock.
3. For drinks, optionally enter **carton price** and **carton quantity**.
4. For clothes, enter **size**, **colors**, **quality/material**, **front photo**, **back photo**, and optional **video URL**.
5. Tick **Nuna a Talla / Featured** if you want the product to appear in the public Talla section.
6. Tick **Visible in store**, then Save.

## Change prices
- Use **Edit** for all product details.
- Use the quick **Farashi** button to change the unit price immediately.
- Use **Carton** to change or remove the carton price.

## Remove an item
- Use **Hide** when the item is temporarily unavailable. This keeps its order history safe.
- Use **Delete** when it has no past orders. If it has past orders, the system hides it instead of deleting the record.

## Customer contact
The store displays **Call** and **WhatsApp** using 08163827505. Add the real Facebook and Instagram URLs under **Admin > Settings**.

## Sabon tsarin Team
- Owner/Super Admin: cikakken iko.
- Admin: products, farashi, stock, orders, payments da settings.
- Staff: **Videos/Talla** kawai a dashboard; yana iya saka product videos har zuwa 10MB ko HTTPS URL.
- Customer Care: **Customer Care, Orders, Customers**; yana kula da kira/WhatsApp da taimakon customers.

## Videos
A public site akwai **🎥 Videos**. Staff ya shiga Admin → Videos, ya zaɓi product idan ya dace, ya upload MP4/WebM/OGG ko ya saka HTTPS URL. Customer zai iya kallon video ya danna Buy Now.

## Catalog
`npm start` yana gudanar da catalog seed kafin server. Seed ɗin ba ya sake rubuta farashi ko stock na products da suka riga sun kasance.


## First-time Admin setup
- On a new/empty database, open **Admin** and choose **Create Admin Account**.
- Enter Name, Email and a password of at least 10 characters.
- After the account is created, use those same credentials to log in.
- The setup form is automatically unavailable once the first owner/admin account exists.
- For a deliberate development reset, stop the server and remove the local `store.db`, then start the app again.


## First admin setup
On a fresh database, open Admin Login and choose **Create Account**. Enter the owner's name, `sulaimanabubakarsultan22@gmail.com`, the Nigerian verification phone `08163827505`, and a password of at least 10 characters. The phone is stored for verification/contact; an SMS/OTP provider is not included until one is configured.

If a previous local database causes `Incorrect email or password`, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `.env` and restart once. The server synchronizes the existing owner credentials from those explicit values, then you may blank `ADMIN_PASSWORD` afterward.
