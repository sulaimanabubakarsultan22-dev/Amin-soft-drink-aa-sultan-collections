# AMIN SOFT DRINK & A.A SULTAN COLLECTIONS — Admin Guide

## Add a new product
1. Open **Admin > Products > + Add product**.
2. Enter the product name, category, unit price and stock.
3. For drinks, optionally enter **carton price** and **carton quantity**.
4. For clothes, enter **size**, **colors**, **quality/material**, **front photo**, **back photo**, and optional **video URL**.
5. Tick **Nuna a Talla / Featured** if you want the product to appear in the public Talla section.
6. Tick **Visible in store**, then Save.

## Change prices
- Use **Edit** for all product details.
- Use the quick **Farashi** button to change the unit price immediately.
- Use **Carton** to change or remove the carton price.

## Remove an item
- Use **Hide** when the item is temporarily unavailable. This keeps its order history safe.
- Use **Delete** when it has no past orders. If it has past orders, the system hides it instead of deleting the record.

## Customer contact
The store displays **Call** and **WhatsApp** using 08163827505. Add the real Facebook and Instagram URLs under **Admin > Settings**.
